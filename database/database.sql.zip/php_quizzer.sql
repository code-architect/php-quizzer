--
-- Database: `php_quizzer`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bengali_question`
--

DROP TABLE IF EXISTS `bengali_question`;
CREATE TABLE `bengali_question` (
  `question_number` int(11) NOT NULL,
  `question` text NOT NULL,
  `question_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bengali_question`
--

INSERT INTO `bengali_question` (`question_number`, `question`, `question_image`) VALUES
(1, 'à¦†à¦ªà¦¨à¦¾à¦° à¦¨à¦¾à¦® à¦•à¦¿ ?', 'example.jpg'),
(2, 'What is the color of the sun?', 'example.jpg'),
(3, 'What is the color of water?', 'example.jpg'),
(4, 'What is the color of banana?', 'example.jpg'),
(5, 'what is the use of pen?', 'example.jpg'),
(6, 'what is the color of apple?', 'example.jpg'),
(7, 'what do we do with knife?', 'example.jpg'),
(8, 'who is stupid?', 'example.jpg'),
(9, 'how do we feel near fire?', 'example.jpg'),
(10, 'which one fly?', 'example.jpg'),
(11, 'which one is the best language?', 'example.jpg'),
(12, 'à¦¯à¦¾à¦°à¦¾ à¦•à¦¾à¦à¦¦à§‡?', 'example.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `beng_choices`
--

DROP TABLE IF EXISTS `beng_choices`;
CREATE TABLE `beng_choices` (
  `id` int(11) NOT NULL,
  `question_number` int(11) NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT '0',
  `answer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `beng_choices`
--

INSERT INTO `beng_choices` (`id`, `question_number`, `is_correct`, `answer`) VALUES
(1, 1, 0, 'indranil'),
(2, 1, 0, 'Rajan'),
(3, 1, 1, 'à¦…à¦­à¦¿à¦·à§‡à¦•'),
(4, 2, 0, 'pink'),
(5, 2, 1, 'yellow'),
(6, 2, 0, 'green'),
(7, 3, 0, 'red'),
(8, 3, 1, 'colorless'),
(9, 3, 0, 'white'),
(10, 4, 0, 'black'),
(11, 4, 1, 'yellow'),
(12, 4, 0, 'orange'),
(13, 5, 1, 'to write'),
(14, 5, 0, 'burn'),
(15, 5, 0, 'kill'),
(16, 6, 0, 'black'),
(17, 6, 1, 'red'),
(18, 6, 0, 'violet'),
(19, 7, 0, 'to kill'),
(20, 7, 0, 'to play'),
(21, 7, 1, 'to cut'),
(22, 8, 0, 'The police'),
(23, 8, 1, 'the people'),
(24, 8, 0, 'the government'),
(25, 9, 1, 'warm'),
(26, 9, 0, 'cold'),
(27, 9, 0, 'nothing'),
(28, 10, 0, 'alligator '),
(29, 10, 0, 'dog'),
(30, 10, 1, 'bird'),
(31, 11, 1, 'php'),
(32, 11, 0, 'c sharp'),
(33, 11, 0, 'java'),
(34, 12, 0, 'à¦ªà§à¦°à¦¾à¦ªà§à¦¤à¦¬à¦¯à¦¼à¦¸à§à¦•'),
(35, 12, 1, 'à¦¶à¦¿à¦¶à§'),
(36, 12, 0, 'à¦›à¦¾à¦¤à§à¦°');

-- --------------------------------------------------------

--
-- Table structure for table `english_question`
--

DROP TABLE IF EXISTS `english_question`;
CREATE TABLE `english_question` (
  `question_number` int(11) NOT NULL,
  `question` text NOT NULL,
  `question_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `english_question`
--

INSERT INTO `english_question` (`question_number`, `question`, `question_image`) VALUES
(1, 'Near a pedestrian crossing, when the pedestrians are waiting to cross the road, you should ', 'Download-Minecraft-Logo-Images-HD-Wallpaper-400x225.jpg'),
(2, 'The following sign represents.', 'example.jpg'),
(3, 'You are approaching a narrow bridge, another vehicle is about to enter the bridge from opposite side you should ', 'example.jpg'),
(4, 'The following sign represents.. ', 'example.jpg'),
(5, 'When a vehicle is involved in an accident causing injury to any person ', 'example.jpg'),
(6, 'The following sign represents... ', 'example.jpg'),
(7, 'On a road designated as one way', 'example.jpg'),
(8, 'The following sign represents.. ', 'example.jpg'),
(9, 'You can overtake a vehicle in front ', 'example.jpg'),
(10, 'The following sign represents.. ', 'no-u-turn.png'),
(11, 'When a vehicle approaches an unguarded railway level crossing, before crossing it, the driver shall ', 'example.jpg'),
(12, 'The following sign represents..', 'pedestrian-crossing.png'),
(13, 'How can you distinguish a transport vehicle.', ''),
(14, 'The following sign represents.. ', 'p-symbol-right-arrow-parking-sign.png'),
(15, 'Validity of learners licence', '');

-- --------------------------------------------------------

--
-- Table structure for table `eng_choices`
--

DROP TABLE IF EXISTS `eng_choices`;
CREATE TABLE `eng_choices` (
  `id` int(11) NOT NULL,
  `question_number` int(11) NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT '0',
  `answer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `eng_choices`
--

INSERT INTO `eng_choices` (`id`, `question_number`, `is_correct`, `answer`) VALUES
(1, 1, 0, 'Sound horn and proceed'),
(2, 1, 0, 'Slow down, sound horn and pass'),
(3, 1, 1, 'Stop the vehicle and wait till the pedestrians cross the road and then proceed '),
(4, 2, 1, 'Stop'),
(5, 2, 0, 'No parking'),
(6, 2, 0, 'Hospital ahead'),
(7, 3, 0, 'Increase the speed and try to cross the bridge as fast as possible '),
(8, 3, 0, 'Put on the head light and pass the bridge'),
(9, 3, 1, 'Wait till the other vehicle crosses the bridge and then proceed'),
(10, 4, 0, 'Keep left '),
(11, 4, 0, 'There is no road to the left '),
(12, 4, 1, 'Compulsory turn left '),
(13, 5, 0, 'Take the vehicle to the nearest police station and report the accident '),
(14, 5, 0, 'Stop the vehicle and report to the police station '),
(15, 5, 1, 'Take all reasonable steps to secure medical attention to the injured and report to the nearest police station within 24 hours '),
(16, 6, 1, 'Give way'),
(17, 6, 0, 'Hospital ahead '),
(18, 6, 0, 'Traffic island ahead'),
(19, 7, 0, 'Parking is prohibited'),
(20, 7, 0, 'Overtaking is prohibited'),
(21, 7, 1, 'Should not drive in reverse gear '),
(22, 8, 0, 'No entry '),
(23, 8, 1, 'One Way'),
(24, 8, 0, 'Speed limit ends'),
(25, 9, 1, 'Through the right side of that vehicle'),
(26, 9, 0, 'Through the left side'),
(27, 9, 0, 'Through the left side, if the road is wide'),
(28, 10, 0, 'Right turn prohibited'),
(29, 10, 0, 'Sharp curve to the right '),
(30, 10, 1, 'U-turn prohibited'),
(31, 11, 1, 'Stop the vehicle on the left side of the road, get down from the vehicle, go to the railway track, and ensure that no train or trolley is coming from either side '),
(32, 11, 0, 'Sound horn and cross the track as fast as possible'),
(33, 11, 0, 'Wait till the train passes'),
(34, 12, 1, 'Pedestrian crossing'),
(35, 12, 0, 'Pedestrians may enter'),
(36, 12, 0, 'Pedestrians prohibited'),
(37, 13, 0, 'By looking at the tyre size.'),
(38, 13, 0, 'By colour of the vehicle.'),
(39, 13, 1, 'By looking at the number plate of the vehicle. '),
(40, 14, 0, 'Keep right side'),
(41, 14, 1, 'Parking on the right allowed'),
(42, 14, 0, 'Compulsory turn to right'),
(43, 15, 0, 'Till the driving licence is obtained'),
(44, 15, 1, '6 months '),
(45, 15, 0, '30 days ');

-- --------------------------------------------------------

--
-- Table structure for table `hindi_question`
--

DROP TABLE IF EXISTS `hindi_question`;
CREATE TABLE `hindi_question` (
  `question_number` int(11) NOT NULL,
  `question` text NOT NULL,
  `question_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hindi_question`
--

INSERT INTO `hindi_question` (`question_number`, `question`, `question_image`) VALUES
(1, 'à¤†à¤ªà¤•à¤¾ à¤¨à¤¾à¤® à¤•à¥à¤¯à¤¾ à¤¹à¥ˆ?', 'Download-Minecraft-Logo-Images-HD-Wallpaper-400x225.jpg'),
(2, 'What is the color of the sun?', 'example.jpg'),
(3, 'What is the color of water?', 'example.jpg'),
(4, 'What is the color of banana?', 'example.jpg'),
(5, 'what is the use of pen?', 'example.jpg'),
(6, 'what is the color of apple?', 'example.jpg'),
(7, 'what do we do with knife?', 'example.jpg'),
(8, 'who is stupid?', 'example.jpg'),
(9, 'how do we feel near fire?', 'example.jpg'),
(10, 'which one fly?', 'example.jpg'),
(11, 'which one is the best language?', 'example.jpg'),
(12, 'à¤‡à¤¸ à¤…à¤¨à¥à¤­à¤¾à¤— à¤•à¥‡ à¤²à¤¿à¤ à¤†à¤ªà¤•à¤¾ à¤¸à¥à¤µà¤¾à¤—à¤¤ à¤¹à¥ˆ', '');

-- --------------------------------------------------------

--
-- Table structure for table `hin_choices`
--

DROP TABLE IF EXISTS `hin_choices`;
CREATE TABLE `hin_choices` (
  `id` int(11) NOT NULL,
  `question_number` int(11) NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT '0',
  `answer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hin_choices`
--

INSERT INTO `hin_choices` (`id`, `question_number`, `is_correct`, `answer`) VALUES
(1, 1, 1, 'à¤‡à¤‚à¤¦à¥à¤°à¤¨à¥€à¤²'),
(2, 1, 0, 'à¤°à¤¾à¤œà¤¨'),
(3, 1, 0, 'à¤…à¤­à¤¿à¤·à¥‡à¤•'),
(4, 2, 0, 'pink'),
(5, 2, 1, 'yellow'),
(6, 2, 0, 'green'),
(7, 3, 0, 'red'),
(8, 3, 1, 'colorless'),
(9, 3, 0, 'white'),
(10, 4, 0, 'black'),
(11, 4, 1, 'yellow'),
(12, 4, 0, 'orange'),
(13, 5, 1, 'to write'),
(14, 5, 0, 'burn'),
(15, 5, 0, 'kill'),
(16, 6, 0, 'black'),
(17, 6, 1, 'red'),
(18, 6, 0, 'violet'),
(19, 7, 0, 'to kill'),
(20, 7, 0, 'to play'),
(21, 7, 1, 'to cut'),
(22, 8, 0, 'The police'),
(23, 8, 1, 'the people'),
(24, 8, 0, 'the government'),
(25, 9, 1, 'warm'),
(26, 9, 0, 'cold'),
(27, 9, 0, 'nothing'),
(28, 10, 0, 'alligator '),
(29, 10, 0, 'dog'),
(30, 10, 1, 'bird'),
(31, 11, 1, 'php'),
(32, 11, 0, 'c sharp'),
(33, 11, 0, 'java'),
(34, 12, 1, 'à¤…à¤šà¥à¤›à¤¾'),
(35, 12, 0, 'à¤®à¤¹à¤¾à¤¨'),
(36, 12, 0, 'à¤¬à¤¾à¤¹à¤° à¤–à¤¡à¤¼à¥‡');

-- --------------------------------------------------------

--
-- Table structure for table `tempo_hin`
--

DROP TABLE IF EXISTS `tempo_hin`;
CREATE TABLE `tempo_hin` (
  `question_id` int(11) NOT NULL,
  `question_number` int(11) NOT NULL,
  `question` text NOT NULL,
  `question_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tempo_hin`
--

INSERT INTO `tempo_hin` (`question_id`, `question_number`, `question`, `question_image`) VALUES
(1, 3, 'What is the color of water?', 'example.jpg'),
(2, 7, 'what do we do with knife?', 'example.jpg'),
(3, 5, 'what is the use of pen?', 'example.jpg'),
(4, 9, 'how do we feel near fire?', 'example.jpg'),
(5, 8, 'who is stupid?', 'example.jpg'),
(6, 2, 'What is the color of the sun?', 'example.jpg'),
(7, 1, 'à¤†à¤ªà¤•à¤¾ à¤¨à¤¾à¤® à¤•à¥à¤¯à¤¾ à¤¹à¥ˆ?', 'Download-Minecraft-Logo-Images-HD-Wallpaper-400x225.jpg'),
(8, 10, 'which one fly?', 'example.jpg'),
(9, 6, 'what is the color of apple?', 'example.jpg'),
(10, 4, 'What is the color of banana?', 'example.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bengali_question`
--
ALTER TABLE `bengali_question`
  ADD PRIMARY KEY (`question_number`);

--
-- Indexes for table `beng_choices`
--
ALTER TABLE `beng_choices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `english_question`
--
ALTER TABLE `english_question`
  ADD PRIMARY KEY (`question_number`);

--
-- Indexes for table `eng_choices`
--
ALTER TABLE `eng_choices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hindi_question`
--
ALTER TABLE `hindi_question`
  ADD PRIMARY KEY (`question_number`);

--
-- Indexes for table `hin_choices`
--
ALTER TABLE `hin_choices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tempo_hin`
--
ALTER TABLE `tempo_hin`
  ADD PRIMARY KEY (`question_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `beng_choices`
--
ALTER TABLE `beng_choices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT for table `eng_choices`
--
ALTER TABLE `eng_choices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT for table `hin_choices`
--
ALTER TABLE `hin_choices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT for table `tempo_hin`
--
ALTER TABLE `tempo_hin`
  MODIFY `question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
